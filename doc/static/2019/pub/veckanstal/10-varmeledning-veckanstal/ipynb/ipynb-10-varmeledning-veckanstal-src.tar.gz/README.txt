This IPython notebook 10-varmeledning-veckanstal.ipynb does not require any additional
programs.
