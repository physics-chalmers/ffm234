This IPython notebook 09-diffekv-veckanstal.ipynb does not require any additional
programs.
