This IPython notebook 02-kroklinjiga_koordinater-veckanstal.ipynb does not require any additional
programs.
