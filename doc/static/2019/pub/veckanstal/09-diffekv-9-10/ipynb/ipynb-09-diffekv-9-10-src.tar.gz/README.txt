This IPython notebook 09-diffekv-9-10.ipynb does not require any additional
programs.
