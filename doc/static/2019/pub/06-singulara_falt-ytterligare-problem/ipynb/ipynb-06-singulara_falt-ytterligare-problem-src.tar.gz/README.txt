This IPython notebook 06-singulara_falt-ytterligare-problem.ipynb does not require any additional
programs.
