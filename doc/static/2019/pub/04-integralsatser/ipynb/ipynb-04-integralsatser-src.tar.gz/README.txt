This IPython notebook 04-integralsatser.ipynb does not require any additional
programs.
