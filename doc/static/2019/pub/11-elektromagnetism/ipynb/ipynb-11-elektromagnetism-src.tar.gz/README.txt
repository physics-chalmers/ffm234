This IPython notebook 11-elektromagnetism.ipynb does not require any additional
programs.
