This IPython notebook 05-indexnotation.ipynb does not require any additional
programs.
