This IPython notebook 12-tensorer.ipynb does not require any additional
programs.
