This IPython notebook 11-elektromagnetism-veckanstal.ipynb does not require any additional
programs.
