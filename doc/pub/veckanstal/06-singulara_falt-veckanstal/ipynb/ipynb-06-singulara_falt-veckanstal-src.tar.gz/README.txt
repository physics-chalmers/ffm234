This IPython notebook 06-singulara_falt-veckanstal.ipynb does not require any additional
programs.
