This IPython notebook 02-kroklinjiga_koordinater-2-14.ipynb does not require any additional
programs.
