This IPython notebook 04-integralsatser-veckanstal.ipynb does not require any additional
programs.
