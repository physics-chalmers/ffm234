This IPython notebook 05-indexnotation-veckanstal.ipynb does not require any additional
programs.
